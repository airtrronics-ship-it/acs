AIRTRONICS CLIMATE SOLUTION — WEBSITE STARTER

Files:
- index.html: responsive one-page website with service sections, contact links and basic LocalBusiness structured data.

Before publishing:
1. Replace https://www.example.com/ in the canonical link with your final website URL.
2. Verify the business phone and full address.
3. Confirm the service list and areas served match your actual business.
4. Add your own company logo and genuine project photos if available.
5. Publish on a domain/hosting service you control.
6. Add the website URL to your Google Business Profile.
7. Set up Google Search Console for the published domain and submit the sitemap if you later create a multi-page site.

This starter file does not publish itself or change your Google Business Profile. Google ranking cannot be guaranteed.
